Finger switch
	author - Manikandan V
	IDE- MikroC for PIC
	Programmer - Pickit2

Description:

	Act as left click of mouse.
	Buzzer sound on each click

Buzzer type - Normal 5V DC buzzer

Files

	USBdsc.c - USB HID configuration file
	fingerswitch.c - Main code 
	fingerswitch.hex - HEX file to upload in PIC184550 Microcontroller
